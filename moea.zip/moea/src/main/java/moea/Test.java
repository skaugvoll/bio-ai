package moea;

import java.util.Arrays;

public class Test {
    public static void main(String[] args) {
        String s = Arrays.toString(new int[] {1, 2});
        System.out.println(s);
    }
}
